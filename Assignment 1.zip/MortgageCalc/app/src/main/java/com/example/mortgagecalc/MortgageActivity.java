package com.example.mortgagecalc;

import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;

public class MortgageActivity extends AppCompatActivity {
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //used for the back button
        getSupportActionBar().setDisplayShowHomeEnabled(true);

       EditText principal =
                (EditText) findViewById(R.id.homevalue);//xml homevalue with java
       EditText interest =
                (EditText) findViewById(R.id.interestrate);//xml interestrate with java
        EditText years =
                (EditText) findViewById(R.id.loanyears);//xml loanyears with java
        EditText total =
                (EditText) findViewById(R.id.interest_total); // xml total with java


        final EditText result =
                (EditText) findViewById(R.id.monthlypayment);
        button = (Button) findViewById(R.id.btn_calculate);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get text to store in the string (initializing three strings to be called and storing it to x1,x2 and x3)
                String x1 =
                        principal.getText().toString();
                String x2 =
                        interest.getText().toString();
                String x3 =
                        years.getText().toString();

                //if...else statement to give a warning if a field is empty and prompts user to
                //input a value
                if (TextUtils.isEmpty(x1))
                {
                    principal.setError("Please enter your home Value");
                    principal.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(x2))
                {
                    interest.setError("Please enter your Interest Rate Value");
                    interest.requestFocus();
                    return;
                }

                if (TextUtils.isEmpty(x3))
                {
                    years.setError("Please enter the number of years");
                    years.requestFocus();
                    return;
                }

                //if the user thas inputted all values in the field then the application
                //should calculate those values inserted with the use of the formula
                else
                {
                    double principal= Double.parseDouble(x1);
                        double interest = Double.parseDouble(x2);
                        double years = Double.parseDouble(x3);

                        double rate = interest/1200;

                        String result =  String.valueOf(((principal*rate*Math.pow(1+rate,years))/(Math.pow(1+rate,years)-1)));

                        total.setText(result);

                }


            }
        });
    }
}