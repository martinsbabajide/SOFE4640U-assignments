package com.example.mortgagecalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.app.Application;


public class Main extends AppCompatActivity {

    //set button as "button1"
    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);

        //calls button from the id set in the main2.xml
        button1 = findViewById(R.id.btn_select);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override

            //intent used to pass the activity of the main page unto the mortgage activity by
            //the click of the button.
            public void onClick(View view) {
                Intent intent = new Intent(Main.this,MortgageActivity.class);
                startActivity(intent);
            }
        });
    }
}
